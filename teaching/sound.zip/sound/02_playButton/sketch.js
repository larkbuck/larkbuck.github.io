'use strict'

let song;

function preload() {
  song = loadSound('../assets/music/free-synth-texture.mp3');
}

function setup() {
}

function draw() {

}
