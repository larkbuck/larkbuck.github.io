'use strict'

// p5 documentation
// https://p5js.org/examples/sound-load-and-play-sound.html

// coding train playlist
// https://www.youtube.com/playlist?list=PLRqwX-V7Uu6aFcVjlDAkkGIixw70s7jpW




function setup() {

}

function draw() {

}
